public class App {

    public static void main(String[] args) {
        // Criação de 3 pizzas com ingredientes diferentes
        Pizza pizza1 = new Pizza();
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");

        Pizza pizza2 = new Pizza();
        pizza2.adicionaIngrediente("Queijo");
        pizza2.adicionaIngrediente("Pepperoni");

        Pizza pizza3 = new Pizza();
        pizza3.adicionaIngrediente("Cogumelos");
        pizza3.adicionaIngrediente("Queijo");
        pizza3.adicionaIngrediente("Tomate");

        // Adição das pizzas em um CarrinhoDeCompra
        CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
        carrinho.adicionaPizza(pizza1);
        carrinho.adicionaPizza(pizza2);
        carrinho.adicionaPizza(pizza3);

        // Impressão do total do CarrinhoDeCompra
        System.out.println("Total no carrinho: R$" + carrinho.calcularTotal());

        // Impressão da quantidade utilizada de cada ingrediente
        System.out.println("Quantidade utilizada de cada ingrediente:");
        for (String ingrediente : pizza1.getIngredientesContagem().keySet()) {
            int quantidade = pizza1.getIngredientesContagem().get(ingrediente);
            System.out.println(ingrediente + ": " + quantidade);
        }
    }
}
