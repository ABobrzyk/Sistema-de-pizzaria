import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Pizza {

    private List<String> ingredientes;
    private static Map<String, Integer> ingredientesContagem = new HashMap<>();

    public Pizza() {
        this.ingredientes = new ArrayList<>();
    }

    public void adicionaIngrediente(String ingrediente) {
        if (!ingrediente.isEmpty()) {
            ingredientes.add(ingrediente);
            contabilizaIngrediente(ingrediente);
        } else {
            System.out.println("Não é possível adicionar uma pizza sem ingredientes.");
        }
    }

    public List<String> getIngredientes() {
        return ingredientes;
    }

    public int getQuantidadeIngredientes() {
        return ingredientes.size();
    }

    public int getPreco() {
        int quantidadeIngredientes = getQuantidadeIngredientes();
        if (quantidadeIngredientes <= 2) {
            return 15;
        } else if (quantidadeIngredientes <= 5) {
            return 20;
        } else {
            return 23;
        }
    }

    public static int getTotalIngredientes() {
        return ingredientesContagem.values().stream().mapToInt(Integer::intValue).sum();
    }

    public static Map<String, Integer> getIngredientesContagem() {
        return ingredientesContagem;
    }

    private static void contabilizaIngrediente(String ingrediente) {
        ingredientesContagem.put(ingrediente, ingredientesContagem.getOrDefault(ingrediente, 0) + 1);
    }
}
